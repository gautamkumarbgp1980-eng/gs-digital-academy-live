# GS Digital Academy — B-TITAN Live Counter

This repository contains the standalone B-TITAN Live Counter page, based on the supplied v100 Anthem Edition HTML.

## Publish with GitHub Pages

1. Create a **Public** GitHub repository named `gs-digital-academy-live-counter`.
2. Upload `index.html` and `README.md` to the repository root.
3. Commit the files to the `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then Save.
7. Wait for GitHub Pages to publish. The site URL will be:
   `https://YOUR-GITHUB-USERNAME.github.io/gs-digital-academy-live-counter/`

## Notes

- `index.html` is a self-contained page and includes its embedded anthem audio and artwork.
- Blockchain values depend on public BNB Smart Chain RPC access and the contract/token addresses already configured in the page.
- Market prices and INR conversions depend on the external price sources configured in the page.
- A live display is not a guarantee of investment returns. Verify contract data independently before relying on it.
- This package has not been deployed to GitHub Pages. Test the published page on mobile after deployment.
